<h1 align="center">
	42 - so_long
</h1>

<p align="center">
	<b><i>Development repo for 42cursus' tnard project at 42 lyon</i></b><br>
</p>

<p align="center">
	<img alt="GitHub code size in bytes" src="https://img.shields.io/github/languages/code-size/PandeoF1/42-so_long?color=blueviolet" />
	<img alt="Number of lines of code" src="https://img.shields.io/tokei/lines/github/PandeoF1/42-so_long?color=blueviolet" />
	<img alt="Code language count" src="https://img.shields.io/github/languages/count/PandeoF1/42-so_long?color=blue" />
	<img alt="GitHub top language" src="https://img.shields.io/github/languages/top/PandeoF1/42-so_long?color=blue" />
	<img alt="GitHub last commit" src="https://img.shields.io/github/last-commit/PandeoF1/42-so_long?color=brightgreen" />
</p>

---

## Tools :
 > - [norminette](https://github.com/42School/norminette) <br />
 > - [Makefile](https://github.com/PandeoF1/makefile) <br />

## (づ｡◕‿‿◕｡)づ :
```
██╗  ██╗██████╗ ██╗  ██╗   ██╗ ██████╗ ███╗   ██╗   ███████╗██████╗ 
██║  ██║╚════██╗██║  ╚██╗ ██╔╝██╔═══██╗████╗  ██║   ██╔════╝██╔══██╗
███████║ █████╔╝██║   ╚████╔╝ ██║   ██║██╔██╗ ██║   █████╗  ██████╔╝
╚════██║██╔═══╝ ██║    ╚██╔╝  ██║   ██║██║╚██╗██║   ██╔══╝  ██╔══██╗
     ██║███████╗███████╗██║   ╚██████╔╝██║ ╚████║██╗██║     ██║  ██║
     ╚═╝╚══════╝╚══════╝╚═╝    ╚═════╝ ╚═╝  ╚═══╝╚═╝╚═╝     ╚═╝  ╚═╝
```
