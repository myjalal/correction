# ft_printf_42
## How would you recreate the C library function `printf`?
My ft_printf function emulates the behaviour of `printf`, but it only runs with formats **cspdiuxX%** and flags **-0.***
